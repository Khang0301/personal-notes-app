import { useState } from 'react'
import { Heart, Plus, Pin, Trash2, X } from 'lucide-react'
import NoteCard from '../../components/notes/NoteCard/NoteCard'
import useNotes from '../../hooks/useNotes'
import { DEFAULT_CATEGORIES } from '../../constants/categories'

function NotesPage() {
    const { notes, addNote, deleteNote, toggleFavorite, togglePin, } = useNotes()

    const [isModalOpen, setIsModalOpen] = useState(false)

    const [formData, setFormData] = useState({
        title: '',
        content: '',
        category: '',
    })

    function handleChange(event) {
        const { name, value } = event.target

        setFormData((prevFormData) => ({
            ...prevFormData,
            [name]: value,
        }))
    }

    function handleSubmit(event) {
        event.preventDefault()

        if (!formData.title.trim()) {
        return
        }

        addNote({
        title: formData.title.trim(),
        content: formData.content.trim(),
        category: formData.category,
        })

        setFormData({
        title: '',
        content: '',
        category: '',
        })

        setIsModalOpen(false)
    }

    function handleCloseModal() {
        setIsModalOpen(false)

        setFormData({
        title: '',
        content: '',
        category: '',
        })
    }

    function handleDelete(noteId) {
        const isConfirmed = window.confirm(
            'Are you sure you want to delete this note?'
        )

        if (!isConfirmed) {
            return
        }

        deleteNote(noteId)
    }

    return (
        <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
            <h1 className="text-2xl font-bold text-slate-900">
                Notes
            </h1>

            <p className="mt-1 text-sm text-slate-500">
                Create and organize your personal notes.
            </p>
            </div>

            <button
                type="button"
                onClick={() => setIsModalOpen(true)}
                className="inline-flex items-center justify-center gap-2 rounded-lg bg-indigo-600 px-4 py-2.5 text-sm font-medium text-white transition hover:bg-indigo-700"
                >
            <Plus size={18} />
            New Note
            </button>
        </div>

        {/* Empty state */}
        {notes.length === 0 && (
            <div className="rounded-xl border border-dashed border-slate-300 bg-white px-6 py-16 text-center">
            <h2 className="text-lg font-semibold text-slate-800">
                No notes yet
            </h2>

            <p className="mt-2 text-sm text-slate-500">
                Create your first note to get started.
            </p>

            <button
                type="button"
                onClick={() => setIsModalOpen(true)}
                className="mt-5 inline-flex items-center gap-2 rounded-lg bg-indigo-600 px-4 py-2.5 text-sm font-medium text-white transition hover:bg-indigo-700"
            >
                <Plus size={18} />
                Create Note
            </button>
            </div>
        )}

        {/* Notes grid */}
        {notes.length > 0 && (
            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {notes.map((note) => (
                <NoteCard
                    key={note.id}
                    note={note}
                    onDelete={handleDelete}
                    onToggleFavorite={toggleFavorite}
                    onTogglePin={togglePin}
                />
            ))}
            </div>
        )}

        {/* Create note modal */}
        {isModalOpen && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 p-4">
            <div className="w-full max-w-lg rounded-2xl bg-white shadow-xl">
                {/* Modal header */}
                <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4">
                <div>
                    <h2 className="text-lg font-semibold text-slate-900">
                    Create new note
                    </h2>

                    <p className="mt-1 text-sm text-slate-500">
                    Add a new note to your collection.
                    </p>
                </div>

                <button
                    type="button"
                    onClick={handleCloseModal}
                    className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-100 hover:text-slate-700"
                >
                    <X size={20} />
                </button>
                </div>

                {/* Form */}
                <form onSubmit={handleSubmit} className="space-y-5 p-6">
                <div>
                    <label
                        htmlFor="title"
                        className="mb-2 block text-sm font-medium text-slate-700"
                        >
                        Title
                    </label>

                    <input
                        id="title"
                        name="title"
                        type="text"
                        value={formData.title}
                        onChange={handleChange}
                        placeholder="Enter note title"
                        className="w-full rounded-lg border border-slate-300 px-3 py-2.5 text-sm outline-none transition placeholder:text-slate-400 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100"
                    />
                </div>

                <div>
                    <label
                        htmlFor="content"
                        className="mb-2 block text-sm font-medium text-slate-700"
                        >
                        Content
                    </label>

                    <textarea
                        id="content"
                        name="content"
                        value={formData.content}
                        onChange={handleChange}
                        rows={6}
                        placeholder="Write your note..."
                        className="w-full resize-none rounded-lg border border-slate-300 px-3 py-2.5 text-sm outline-none transition placeholder:text-slate-400 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100"
                    />
                </div>

                <div>
                    <label
                        htmlFor="category"
                        className="mb-2 block text-sm font-medium text-slate-700"
                        >
                        Category
                    </label>

                    <select
                        id="category"
                        name="category"
                        value={formData.category}
                        onChange={handleChange}
                        className="w-full rounded-lg border border-slate-300 px-3 py-2.5 text-sm outline-none transition focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100"
                        >
                        <option value="">Uncategorized</option>

                        {DEFAULT_CATEGORIES.map((category) => (
                            <option key={category} value={category}>
                            {category}
                            </option>
                        ))}
                    </select>
                </div>

                <div className="flex justify-end gap-3 border-t border-slate-100 pt-5">
                    <button
                        type="button"
                        onClick={handleCloseModal}
                        className="rounded-lg border border-slate-300 px-4 py-2.5 text-sm font-medium text-slate-700 transition hover:bg-slate-50"
                        >
                        Cancel
                    </button>

                    <button
                        type="submit"
                        disabled={!formData.title.trim()}
                        className="rounded-lg bg-indigo-600 px-4 py-2.5 text-sm font-medium text-white transition hover:bg-indigo-700 disabled:cursor-not-allowed disabled:opacity-50"
                        >
                        Create Note
                    </button>
                </div>
                </form>
            </div>
            </div>
        )}
        </div>
    )
}

export default NotesPage